package com.example.honeytips

class HoneyTips {

    var Category: String = ""
    var Subject: String = ""
    var Contents: String = ""

    constructor(Category: String, Subject: String, Contents: String) {
        this.Category = Category
        this.Subject = Subject
        this.Contents = Contents
    }

    constructor() {

    }

}